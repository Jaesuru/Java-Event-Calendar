package util;

public class Date implements Comparable<Date>{
    private int day;
    private int month;
    private int year;

    @Override
    public String toString() {
        return String.format("%02d/%02d/%04d", month, day, year);
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public Date(int day, int month, int year) {
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public static int monthLength(int month, int year){
        switch(month){
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                return 31;
            case 4: case 6: case 9: case 11:
                return 30;
            default:
                if(year % 400 == 0 || year % 4 == 0 && year % 100 != 0) {
                    return 29;
                }else{
                    return 28;
                }
        }
    }

    @Override
    public int compareTo(Date other) {
        if(this.year != other.year)
            return this.year - other.year;//new Integer(year).compareTo(other.year);
        if(this.month != other.month)
            return this.month - other.month;
        return this.day - other.day;
    }
}
