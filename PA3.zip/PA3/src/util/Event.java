package util;

import java.util.ArrayList;

public class Event implements Comparable<Event>{

    private String name;
    private DateTime startDate;
    private DateTime endDate;
    private String host;
    private int invites;

    private static ArrayList<Event> events = new ArrayList<>();

    public static ArrayList<Event> getEvents() {
        return events;
    }
    public String getName() {
        return name;
    }

    public DateTime getStartDate() {
        return startDate;
    }

    public DateTime getEndDate() {
        return endDate;
    }

    public String getHost() {
        return host;
    }

    public int getInvites() {
        return invites;
    }

    public String getLocation() {
        return location;
    }


    private String location;

    public Event(String name, DateTime startDate, DateTime endDate, String host, int invites, String location) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.host = host;
        this.invites = invites;
        this.location = location;
    }

    public static void addEvent(String name, DateTime startDate, DateTime endDate, String host, int invites, String location) {
        events.add(new Event(name, startDate, endDate, host, invites, location));
    }

    @Override
    public int compareTo(Event other) {
        if (this.startDate.compareTo(other.startDate) != 0){
            return this.startDate.compareTo(other.startDate);
        }

        if (other.endDate.compareTo(this.endDate) != 0){
            return other.endDate.compareTo(this.endDate);
        }

        return this.name.compareTo(other.name);
    }

    @Override
    public String toString() {
        return "Event Name: " + name + "\n" +
                "Start Date and Time: " + startDate + "\n" +
                "End Date and Time: " + endDate + "\n" +
                "Host: " + host + "\n" +
                "Number of Invitees: " + invites + "\n" +
                "Location: " + location + "\n";
    }
}
