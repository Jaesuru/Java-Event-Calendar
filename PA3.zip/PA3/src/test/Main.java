package test;
import util.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import static util.Date.monthLength;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("\nPlease enter each information about an event listed below separated by commas:");
        System.out.println("--------------------------------------------------------------------------------");
        System.out.println("Event name (String with no comma)");
        System.out.println("Start date and time (MM/DD/YYYY @hh:mm:ss am/pm)");
        System.out.println("End date and time (MM/DD/YYYY @hh:mm:ss am/pm)");
        System.out.println("Host (String with no comma)");
        System.out.println("Number of Invites (int)");
        System.out.println("Location (String with no comma)");
        System.out.println("--------------------------------------------------------------------------------\n");

        while (true) {
            String userInput = sc.nextLine();

            if (userInput.equalsIgnoreCase("done")) {
                break;
            }

            String[] inputParse = userInput.split(",");
            if (inputParse.length != 6) {
                System.out.println("\nInvalid format. Please retry.\n");
                continue;
            }

            String name = inputParse[0];
            String startDateStr = inputParse[1];
            String endDateStr = inputParse[2];
            String host = inputParse[3];
            int invites = Integer.parseInt(inputParse[4]);
            String location = inputParse[5];

            DateTime startDateTime = parseDateTime(startDateStr);
            DateTime endDateTime = parseDateTime(endDateStr);

            if (startDateTime == null || endDateTime == null) {
                System.out.println("\nInvalid date/time format. Please retry.\n");
                continue;
            }

            if (startDateTime.compareTo(endDateTime) > 0) {
                System.out.println("\nThe start date and time cannot be at a later time than the end date and time.");
                System.out.println("Please try again.\n");
                continue;
            }

            Event.addEvent(name, startDateTime, endDateTime, host, invites, location);

            System.out.println("\nEvent added.\n");
        }

        while(true) {
            System.out.println("\nPlease enter a command: (quit, print, happening on MM/DD/YYYY @hh:mm:ss am/pm, hosted by hostname (Case-sensitive!))");
            String command = sc.nextLine();

            if (command.equals("quit")) {
                break;

            } else if (command.equals("print")) {
                printEvents();

            } else if (command.startsWith("happening on")) {
                String[] timeParts = command.split(" ");

                if (timeParts.length == 5) {
                    String specifiedTime = (timeParts[2] + " " + timeParts[3] + " " + timeParts[4]);

                    DateTime happeningTime = parseDateTime(specifiedTime);

                    if (happeningTime != null) {
                        printHappening(happeningTime);

                    } else {
                        System.out.println("\nInvalid date formatting. Please try again.\n");
                    }
                }else{
                    System.out.println("\nInvalid formatting. Please try again.");
                }

                if(timeParts.length != 5){
                    System.out.println("\nPlease enter a date after the command in the format: ");
                    System.out.println("MM/DD/YYYY @hh:mm:ss am/pm\n");
                }


            } else if (command.startsWith("hosted by")) {
                String[] hostParts = command.split(" ");

                if (hostParts.length == 3) {
                    String hostName = hostParts[2];
                    printHosted(hostName);
                }
            }

            else {
                System.out.println("\nInvalid command. Please try again.\n");
            }
        }
    }
    private static DateTime parseDateTime(String dateTimeStr) {
        try {
            String[] dateTimeParts = dateTimeStr.split(" @");
            String dateStr = dateTimeParts[0];
            String dateTimes = dateTimeParts[1];

            String[] dateParts = dateStr.split("/");
            int year = Integer.parseInt(dateParts[2]);
            int month = Integer.parseInt(dateParts[0]);
            int day = Integer.parseInt(dateParts[1]);

            String[] separateTime = dateTimes.split(" ");
            String time = separateTime[0];
            String amOrPm = separateTime[1];

            String[] timeParts = time.split(":");

            int hour = Integer.parseInt(timeParts[0]);
            int minute = Integer.parseInt(timeParts[1]);
            int second = Integer.parseInt(timeParts[2]);

            boolean isAm = amOrPm.equalsIgnoreCase("am");

            if (month == 2) {
                int febDays = monthLength(month, year);
                if (day < 1 || day > febDays) {
                    System.out.println("\nInvalid day for February in the given year. Please retry.\n");
                    return null;
                }
            } else {
                int monthDays = monthLength(month, year);
                if (day < 1 || day > monthDays) {
                    System.out.println("\nInvalid day for the given month and year. Please retry.\n");
                    return null;
                }
            }

            Date date = new Date(day, month, year);
            return new DateTime(date, hour, minute, second, isAm);

        } catch (Exception e) {
            System.out.println("\nInvalid date formatting.\n");
            return null;
        }
    }

    private static void printEvents(){
        ArrayList<Event> events = Event.getEvents();

        Collections.sort(events);
        for(Event event : events){
            System.out.println(event);
        }
    }

    private static void printHappening(DateTime happeningTime){
        ArrayList<Event> events = Event.getEvents();
        ArrayList<Event> eventsHappening = new ArrayList<>();

        for (Event event : events) {
            if (event.getStartDate().compareTo(happeningTime) == 0) {
                eventsHappening.add(event);
            }
        }
        Collections.sort(eventsHappening);
        for (Event event : eventsHappening) {
            System.out.println(event);
        }
    }

    private static void printHosted(String hostName){
        ArrayList<Event> events = Event.getEvents();
        ArrayList<Event> hostEvents = new ArrayList<>();

        for(Event event : events) {
            if (event.getHost().compareTo(hostName) == 0) {
                hostEvents.add(event);
            }
        }
        Collections.sort(hostEvents);
        for(Event event : hostEvents) {
            System.out.println(event);
        }
    }
}
